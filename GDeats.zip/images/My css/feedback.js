function commentBtn(){
    alert("Your response was submitted successfully!");
}